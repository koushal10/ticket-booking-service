package com.altimetric.paypal.ticket.exception;

/**
 * Created by Malikhan Kaushal on 7/28/2020.
 *
 * Exception that is raised when input details for seat reservation are not valid
 */
public class SeatReservationNotValidException extends RuntimeException{

    public SeatReservationNotValidException(String message) {
        super(message);
    }
}

package com.altimetric.paypal.ticket.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.altimetric.paypal.ticket.controller.TicketController;
import com.altimetric.paypal.ticket.exception.handler.TicketExceptionHandler;
import com.altimetric.paypal.ticket.service.TicketService;

/**
 * Created by Malikhan Kaushal on 7/28/2020.
 */
@Configuration
public class ControllerConfiguration {
    @Bean
    public TicketController ticketController(final TicketService ticketService){
        return new TicketController(ticketService);
    }

    @Bean
    public TicketExceptionHandler ticketExceptionHandler(){
        return new TicketExceptionHandler();
    }
}

package com.altimetric.paypal.ticket.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import com.altimetric.paypal.ticket.repository.TicketRepository;
import com.altimetric.paypal.ticket.service.TicketService;
import com.altimetric.paypal.ticket.service.TicketServiceImpl;
import com.altimetric.paypal.ticket.service.TicketValidator;

/**
 * Created by Malikhan Kaushal on 7/28/2020.
 */
@Configuration
public class ServiceConfiguration {

    @Bean
    public TicketService ticketService(final TicketValidator ticketValidator,
                                       final TicketRepository ticketRepository,
                                       final Environment environment){
        return new TicketServiceImpl(ticketValidator, ticketRepository,
                environment.getProperty("seat.hold.expiration.seconds", Integer.class));
    }

}

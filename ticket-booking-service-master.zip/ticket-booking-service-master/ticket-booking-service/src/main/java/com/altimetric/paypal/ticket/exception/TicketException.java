package com.altimetric.paypal.ticket.exception;

/**
 * Created by Malikhan Kaushal on 7/28/2020.
 *
 * {@link RuntimeException} that is thrown whenever there is an issue in accessing
 * any restful service in ticket-booking-service application
 */
public class TicketException extends RuntimeException {

    public TicketException(String message) {
        super(message);
    }

    public TicketException(String message, Throwable cause) {
        super(message, cause);
    }

    public TicketException(Throwable cause) {
        super(cause);
    }
}

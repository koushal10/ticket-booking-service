package com.altimetric.paypal.ticket.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 * Created by Malikhan Kaushal on 7/28/2020.
 */
@Configuration
@PropertySource({"classpath:database/sql-query.properties", "classpath:common.properties"})
public class PropertyConfiguration {
}

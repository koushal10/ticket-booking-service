package com.altimetric.paypal.ticket.repository;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.altimetric.paypal.ticket.common.entity.Customer;
import com.altimetric.paypal.ticket.repository.entity.TicketTableColumn;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by Malikhan Kaushal on 7/28/2020.
 *
 * {@link ResultSetExtractor} that extract customer details from {@link ResultSet}
 */
public class CustomerExtractor implements ResultSetExtractor<Customer> {

    @Override
    public Customer extractData(ResultSet rs) throws SQLException, DataAccessException {
        Customer customer = null;
        if(rs.isBeforeFirst()){
            while(rs.next()){
                customer = new Customer();
                customer.setId(rs.getLong(TicketTableColumn.CUSTOMER_ID.name()));
                customer.setEmail(rs.getString(TicketTableColumn.EMAIL.name()));
            }
        }
        return customer;
    }
}

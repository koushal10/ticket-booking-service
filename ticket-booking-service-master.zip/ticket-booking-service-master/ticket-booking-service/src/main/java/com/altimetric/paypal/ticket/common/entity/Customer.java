package com.altimetric.paypal.ticket.common.entity;

/**
 * Created by Malikhan Kaushal on 7/28/2020.
 *
 * Entity that stores customer details
 */
public class Customer {

    private long id;
    private String email;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "id=" + id +
                ", email='" + email + '\'' +
                '}';
    }
}

package com.altimetric.paypal.ticket.exception;

import java.util.List;

import com.altimetric.paypal.ticket.common.entity.ClientError;

/**
 * Created by Malikhan Kaushal on 7/28/2020.
 *
 * {@link RuntimeException} used for validation clientErrors
 */
public class CustomValidationException extends RuntimeException {

    private final List<ClientError> clientErrors;

    public CustomValidationException(final List<ClientError> clientErrors) {
        this.clientErrors = clientErrors;
    }

    public List<ClientError> getClientErrors() {
        return clientErrors;
    }
}

package com.altimetric.paypal.ticket.exception;

/**
 * Created by Malikhan Kaushal on 7/28/2020.
 *
 * {@link RuntimeException} that is thrown when a seat hold is not found
 */
public class SeatHoldNotFoundException extends RuntimeException{

    public SeatHoldNotFoundException(String message) {
        super(message);
    }
}

package com.altimetric.paypal.ticket.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.altimetric.paypal.ticket.service.TicketValidator;
import com.altimetric.paypal.ticket.service.TicketValidatorImpl;

/**
 * Created by Malikhan Kaushal on 7/28/2020.
 */
@Configuration
public class BusinessConfiguration {
    @Bean
    public TicketValidator ticketValidator(){
        return new TicketValidatorImpl();
    }
}
